package com.example.demo;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TestMongodb implements CommandLineRunner
{
@Autowired
private EmployeeRepository repo;
	@Override
	public void run(String... args) throws Exception 
	{
	Employee emp=new Employee();
	Scanner ob=new Scanner(System.in);
	System.out.println("enter id,empid,name,salary");
		String id=ob.next();
		int eid=ob.nextInt();
		String name=ob.next();
		Double sal=ob.nextDouble();
		emp.setId(id);
		emp.setEid(eid);
		emp.setEname(name);
		emp.setEsal(sal);
		repo.save(emp);
		repo.deleteAll();
		Employee emp1=new Employee(id,eid,name,sal);
		repo.save(emp1);
		Employee emp2=new Employee("amdocs102",1002,"sandip",76000.43);
		repo.save(emp2);
		Employee emp3=new Employee("amdocs103",1003,"Madhu",86000.43);
		repo.save(emp3);
		
		repo.findAll().forEach(System.out::println);
			
	}

}
