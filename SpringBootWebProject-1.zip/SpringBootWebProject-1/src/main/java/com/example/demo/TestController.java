package com.example.demo;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController
{
@Autowired
private JdbcTemplate jt;
private HttpServletRequest req;
private HttpServletResponse res;
@GetMapping("/show")
public String showLogin()
{
	return "Register";
}
@RequestMapping("/register")
public String doRegister(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	String a=req.getParameter("t1");
	String b=req.getParameter("t2");
	String c=req.getParameter("t3");
	String d=req.getParameter("t4");
	String e=req.getParameter("t5");
	String f=req.getParameter("t6");
	String sql="insert into Amdocsemp values(?,?,?,?,?,?)";
	int count=jt.update(sql,a,b,c,d,e,f);
	pw.println("row inserted "+count);
	return "success";
}
}
