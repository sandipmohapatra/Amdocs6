public class Student 
{
private int studid;
private String name,address;
public int getStudid() {
	return studid;
}
public void setStudid(int studid) {
	this.studid = studid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public void displayStudent() {
System.out.println("studid=" + studid + ", name=" + name + ", address=" + address );
}

}
